#include <iostream>
#include <string>

bool check_pass(std::string text)
{
    return text == "this_was_easy";
}

int main()
{
    std::string password;
    std::cout << "Enter password: ";
    std::cin >> password;
    if (check_pass(password))
    {
        std::cout << "ACL{" << password << "}" << std::endl;
    }
    else
    {
        std::cout << "Wrong password" << std::endl;
    }
    system("PAUSE");
}